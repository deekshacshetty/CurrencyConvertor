package com.currencyconverter;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.currencyconverter.convertor.CurrencyConvertor;
import com.currencyconverter.utility.RateHandler;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CurrencyConverterApplicationTests
{

    @Autowired
    CurrencyConvertor convertor;

    @Autowired
    RateHandler rateHandler;

    @Test
    public void testRateValid()
    {
        String rate = rateHandler.getRate("AUD", "USD");
        assertEquals("0.8371", rate);
    }

    @Test
    public void testIndirectRateValid()
    {
        String rate = rateHandler.getRate("NOK", "USD");
        assertEquals("0.14212184510276857", rate);
    }

    @Test
    public void testCrossRateValid()
    {
        String rate = rateHandler.getRate("USD", "AUD");
        assertEquals("1.1946004061641382", rate);
    }

    @Test
    public void testSimpleConvert()
    {

        String result = convertor.convert("AUD", "1000", "USD");

        assertEquals("837.10", result);

    }

    @Test
    public void testCrossCurrConvert()
    {

        String result = convertor.convert("AUD", "1000", "CNY");

        assertEquals("5166.16", result);

    }

    @Test
    public void testInvaidFromCurr()
    {

        String result = convertor.convert("AUDed", "1000", "CNY");

        assertEquals(null, result);

    }

    @Test
    public void testConversionToJPY()
    {

        String result = convertor.convert("USD", "1", "JPY");

        assertEquals("120", result);

    }
}
