package com.currencyconverter;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.currencyconverter.convertor.CurrencyConvertor;
import com.currencyconverter.service.ConvertorService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CurrencyConverterApplicationTests {

    private static ConvertorService convertor = new CurrencyConvertor();

    @Test
    public void testSimpleConvert() {

        String result = convertor.convert("AUD", "1000", "USD");

        assertEquals("837.10", result);

    }

    @Test
    public void testCrossCurrConvert() {

        String result = convertor.convert("AUD", "1000", "CNY");

        assertEquals("5166.16", result);

    }

    @Test
    public void testInvaidFromCurr() {

        String result = convertor.convert("AUDed", "1000", "CNY");

        assertEquals(null, result);

    }

    @Test
    public void testConversionToJPY() {

        String result = convertor.convert("USD", "1", "JPY");

        assertEquals("120", result);

    }
}
