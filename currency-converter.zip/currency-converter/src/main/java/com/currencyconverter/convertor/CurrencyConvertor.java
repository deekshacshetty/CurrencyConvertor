package com.currencyconverter.convertor;

import org.springframework.stereotype.Component;

import com.currencyconverter.service.ConvertorService;
import com.currencyconverter.utility.RateHandler;

/**
 * 
 * Class for currency conversion
 * 
 * @author deshett3
 *
 */
@Component
public class CurrencyConvertor implements ConvertorService {

    /*
     * (non-Javadoc)
     * 
     * @see com.currencyconverter.service.ConvertorService#convert(java.lang.String,
     * java.lang.String, java.lang.String)
     */
    public String convert(String fromCurrency, String fromAmount, String toCurrency) {

        String strRate = RateHandler.getRate(fromCurrency, toCurrency);
        String formatedString = null;

        try {
            if (null != strRate) {
                double conversionFactor = Double.parseDouble(strRate);
                double amount = Double.parseDouble(fromAmount);
                if (toCurrency.equalsIgnoreCase("JPY")) {
                    formatedString = String.format("%.0f", (conversionFactor * amount));

                }
                else {
                    formatedString = String.format("%.2f", (conversionFactor * amount));
                }
            }
        }
        catch (Exception e) {
            formatedString = null;
        }
        return formatedString;
    }

}
