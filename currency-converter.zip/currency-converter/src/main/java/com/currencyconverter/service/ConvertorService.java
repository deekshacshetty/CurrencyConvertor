package com.currencyconverter.service;

/**
 * Interface of Convertor
 * 
 * @author deshett3
 *
 */
public interface ConvertorService {

    String convert(String fromCurrency, String fromAmount, String toCurrency);

}
