package com.currencyconverter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.currencyconverter.utility.PropertiesHandler;

@SpringBootApplication
public class CurrencyConverterApplication {

    public CurrencyConverterApplication() {
        PropertiesHandler.initialize();
    }

    @RequestMapping("/")
    String home() {
        return "Welcome to currency convertor";
    }

    @RequestMapping(value = "/convert/{fromCurrency}/{fromAmount}/{toCurrency}", method = RequestMethod.GET)
    String convert(@PathVariable String fromCurrency, @PathVariable String toCurrency) {
        return fromCurrency + toCurrency;
    }

    public static void main(String[] args) {
        SpringApplication.run(CurrencyConverterApplication.class, args);
    }

}
