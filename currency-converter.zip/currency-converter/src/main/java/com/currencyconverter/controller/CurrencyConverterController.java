package com.currencyconverter.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.currencyconverter.service.ConvertorService;

/**
 * Controller class for the screens
 * 
 * @author deshett3
 *
 */
@Controller
public class CurrencyConverterController {

    private static String INPUT_URL = "inputValues";

    @Autowired
    ConvertorService currConver;

    @GetMapping("/")
    public String greeting(@RequestParam(name = "name", required = false, defaultValue = "World") String name, Model model) {
        model.addAttribute("name", name);
        return INPUT_URL;
    }

    @GetMapping("/error")
    public String error() {
        return INPUT_URL;
    }

    @GetMapping("/back")
    public String back() {
        return INPUT_URL;
    }

    @GetMapping("/convert")
    public String convertedAmount(@RequestParam(name = "fromCurrency", required = true) String fromCurrency,
            @RequestParam(name = "fromAmount", required = true) String fromAmount,
            @RequestParam(name = "toCurrency", required = true) String toCurrency, Model model) {
        String returnURL = "output";

        model.addAttribute("fromCurrency", fromCurrency);
        model.addAttribute("toCurrency", toCurrency);

        if (isEmptyOrNull(fromCurrency) || isEmptyOrNull(toCurrency) || isEmptyOrNull(fromAmount)) {
            return "invalidValues";
        }

        String toAmount = currConver.convert(fromCurrency, fromAmount, toCurrency);
        model.addAttribute("fromAmount", fromAmount);

        if (null == toAmount) {
            returnURL = "invalidValues";
        }
        else {

            model.addAttribute("calculateValue", toAmount);
        }

        return returnURL;

    }

    private boolean isEmptyOrNull(String value) {
        boolean ret = false;

        if (null == value || value.isEmpty()) {
            ret = true;
        }

        return ret;
    }

}
