package com.currencyconverter.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PropertiesHandler {

    private static Log logger = LogFactory.getLog(PropertiesHandler.class);
    private static PropertiesHandler propertiesHandler = null;
    private static Map<String, String> properties = null;
    private static Map<String, ArrayList> currencies = null;
    private BufferedReader reader;
    public final static String EXT_PROPERTIES_FILE = ".\\src\\main\\resources\\extention.properties";

    private PropertiesHandler() {
    }

    /**
     * Static method to return the singleton class.
     * 
     * @return PropertiesHandler
     */
    private static void initializeAndLoadProperties() {
        if (propertiesHandler == null) {
            propertiesHandler = new PropertiesHandler();
            properties = new HashMap<String, String>();
            currencies = new HashMap<String, ArrayList>();
            propertiesHandler.loadProperties();
        }
    }

    /**
     * Load application properties from the specified file
     * 
     * @param filename
     *            - Name of the properties file
     */
    private Map<String, String> loadProperty(String filename) {

        logger.debug("Reading " + filename);

        String line = null;
        String errorMessage = null;
        Map<String, String> propertiesMap = new HashMap<String, String>();

        try {
            File propertiesFile = new File(filename);
            if (!propertiesFile.exists()) {
                errorMessage = "File not found - \"" + filename + "\"";
                logger.error(errorMessage);
                System.exit(-1);
            }

            reader = new BufferedReader(new FileReader(propertiesFile));
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.length() != 0) {
                    if ('*' == line.charAt(0) || '#' == line.charAt(0)) {
                    }
                    else {
                        logger.debug(line);
                        int subIndex = line.indexOf('=');
                        if (subIndex > 1) {
                            String childName = line.substring(0, subIndex).trim();
                            String childValue = line.substring(subIndex + 1).trim();
                            if (childValue.length() == 0) {
                                errorMessage = "No value specified for the property \"" + childName + "\" in \"" + filename + "\".";
                                logger.error(errorMessage);
                            }
                            propertiesMap.put(childName.toUpperCase(), childValue);
                            populateCurrencyCombinations(childName.toUpperCase());
                        }
                    }
                }
            }
        }
        catch (FileNotFoundException fileNotFoundException) {
            errorMessage = "File not found - \"" + filename + "\"";
            logger.error(errorMessage);
            logger.debug("Error Stack Trace", fileNotFoundException);
            System.exit(-1);
        }
        catch (IOException ioException) {
            errorMessage = "Unable to read the properties file \"" + filename + "\"";
            logger.error(errorMessage);
            logger.debug("Error Stack Trace", ioException);
            System.exit(-1);
        }

        reader = null;
        return propertiesMap;
    }

    private void populateCurrencyCombinations(String combination) {

        String[] fromToCurr = combination.split("-");

        if (null == currencies.get(fromToCurr[0])) {

            ArrayList listToCurrencies = new ArrayList<>();
            listToCurrencies.add(fromToCurr[1]);
            currencies.put(fromToCurr[0], listToCurrencies);
        }
        else {
            ArrayList listToCurrencies = currencies.get(fromToCurr[0]);
            listToCurrencies.add(fromToCurr[1]);
            currencies.put(fromToCurr[0], listToCurrencies);
        }

    }

    /**
     * Load the application properties.
     */
    private void loadProperties() {

        properties.putAll(propertiesHandler.loadProperty(EXT_PROPERTIES_FILE));
    }

    /**
     * Get the properties
     * 
     * @return
     */
    public static Map getCurrencies() {
        return currencies;
    }

    /**
     * Return the value of the specified application property
     * 
     * @param propertyKey
     *            - Application property name
     * @return String - Value of the property
     */
    public static String getProperty(String propertyKey) {
        return String.valueOf(properties.get(propertyKey));
    }

    /**
     * This class will be initialized on the application startup. So this method need not be called
     * anywhere else in the application.
     */
    public static void initialize() {
        initializeAndLoadProperties();
    }

}
