package com.currencyconverter.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:extention.properties")
@ConfigurationProperties(prefix = "")
public class PropertiesHandler
{

    private Map<String, String> properties = new HashMap<>();

    private Map<String, String> currency = new HashMap<>();

    private Map<String, List<String>> currencies = new HashMap<>();

    public Map<String, String> getCurrency()
    {
        return currency;
    }

    @PostConstruct
    private void loadProperty()
    {

        currency.entrySet().stream().forEach(stringStringEntry -> {
            String conversionName = stringStringEntry.getKey().toUpperCase();
            String conversionValue = stringStringEntry.getValue();
            properties.put(conversionName, conversionValue);
            populateCurrencyCombinations(conversionName);
            insertReverse(conversionName, conversionValue);

        });

    }

    private void insertReverse(String childName, String childValue)
    {
        String[] fromCurr = childName.split("-");
        String currencyPair = fromCurr[1] + "-" + fromCurr[0];
        properties.put(currencyPair, (1 / Double.parseDouble(childValue)) + "");
        populateCurrencyCombinations(currencyPair);
    }

    private void populateCurrencyCombinations(String combination)
    {

        String[] fromToCurr = combination.split("-");

        List<String> listToCurrencies;

        if (null == currencies.get(fromToCurr[0])) {

            listToCurrencies = new ArrayList<>();
            currencies.put(fromToCurr[0], listToCurrencies);

        } else {
            listToCurrencies = currencies.get(fromToCurr[0]);

        }

        listToCurrencies.add(fromToCurr[1]);

    }

    /**
     * Get the properties
     *
     * @return
     */
    public Map<String, List<String>> getCurrencies()
    {
        return currencies;
    }

    /**
     * Return the value of the specified application property
     *
     * @param propertyKey - Application property name
     * @return String - Value of the property
     */
    public String getProperty(String propertyKey)
    {
        return String.valueOf(properties.get(propertyKey));
    }

}
