package com.currencyconverter.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Class contains the method to get the rates for currencies
 * 
 * @author deshett3
 */
@Component
public class RateHandler
{

    private RateHandler()
    {

    }

    @Autowired
    PropertiesHandler propertiesHandler;

    private Map<String, Vertex> mapVertex;

    @PostConstruct
    public void createEdges()
    {

        Set<String> alCurrencies = propertiesHandler.getCurrencies().keySet();
        mapVertex = getVertexesForAllCurrencies(alCurrencies);
        Map<String, List<String>> mapConversions = propertiesHandler.getCurrencies();

        alCurrencies.stream().forEach(currency -> {
            Vertex vertex = mapVertex.get(currency);
            List alConversions = mapConversions.get(currency);

            Edge[] toCurrencies = new Edge[0];
            if (null != alConversions) {
                toCurrencies = new Edge[alConversions.size()];
                for (int j = 0; j < alConversions.size(); j++) {
                    String destCurr = (String) alConversions.get(j);
                    Vertex dest = mapVertex.get(destCurr);
                    Edge edgeCurrency = new Edge(dest, 1);
                    toCurrencies[j] = edgeCurrency;
                }

            }
            vertex.adjacencies = toCurrencies;

        });

    }

    /**
     * method to get the rates
     * 
     * @param fromCurrency
     * @param toCurrency
     * @return
     */
    public String getRate(String fromCurrency, String toCurrency)
    {
        String strRate;

        String strProperty = propertiesHandler.getProperty(fromCurrency + "-" + toCurrency);

        if (strProperty.equals("null")) {
            strRate = getCrossRate(fromCurrency, toCurrency);
        } else {
            strRate = propertiesHandler.getProperty(fromCurrency + "-" + toCurrency);

        }

        return strRate;
    }

    /**
     * method to get the cross rate
     * 
     * @param fromCurrency
     * @param toCurrency
     * @return
     */
    private String getCrossRate(String fromCurrency, String toCurrency)
    {
        String strRate = null;

        /**
         * If valid from and To currencies are not entered return null
         */

        if (!propertiesHandler.getCurrencies().containsKey(fromCurrency)
            || !propertiesHandler.getCurrencies().containsKey(toCurrency)) {
            return null;
        }

        mapVertex.values().stream().forEach(vertex -> vertex.setDefaults());

        Vertex source = mapVertex.get(fromCurrency);

        Vertex vertexToCurrency = mapVertex.get(toCurrency);

        Dijkstra.computePaths(source);

        ArrayList<Vertex> path = (ArrayList<Vertex>) Dijkstra.getShortestPathTo(vertexToCurrency);

        if (null != path && path.size() > 1) {
            strRate = getFinalRate(path);
        }

        return strRate;
    }

    /**
     * get the final rate based on shortest Path from the Dijistra algorithm
     * 
     * @param path
     * @return
     */
    private String getFinalRate(List<Vertex> path)
    {

        String strRate;
        Double finalRate = (double) 1;

        for (int i = 1; i < path.size(); i++) {
            Vertex srcCurr = path.get(i - 1);
            Vertex destCurr = path.get(i);

            String key = srcCurr.name + "-" + destCurr.name;
            String rate = propertiesHandler.getProperty(key);
            finalRate = finalRate * Double.parseDouble(rate);
        }
        strRate = "" + finalRate;

        return strRate;

    }

    /**
     * method to get the vertex for running the algorithm
     * 
     * @param alCurrencies
     * @return
     */
    private Map getVertexesForAllCurrencies(Set<String> alCurrencies)
    {

        Map<String, Vertex> mapVertex = new HashMap<>();

        alCurrencies.stream().forEach(currency -> {
            Vertex vertex = new Vertex(currency);
            mapVertex.put(currency, vertex);
        });

        return mapVertex;
    }

}
