package com.currencyconverter.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

/**
 * Class contains the method to get the rates for currencies
 * 
 * @author deshett3
 *
 */
@Component
public class RateHandler {

    private RateHandler() {

    }

    /**
     * method to get the rates
     * 
     * @param fromCurrency
     * @param toCurrency
     * @return
     */
    public static String getRate(String fromCurrency, String toCurrency) {
        String strRate = null;

        String strProperty = PropertiesHandler.getProperty(fromCurrency + "-" + toCurrency);

        if (strProperty.equals("null")) {
            strRate = getCrossRate(fromCurrency, toCurrency);
        }
        else {
            strRate = PropertiesHandler.getProperty(fromCurrency + "-" + toCurrency);

        }

        return strRate;
    }

    /**
     * method to get the cross rate
     * 
     * @param fromCurrency
     * @param toCurrency
     * @return
     */
    private static String getCrossRate(String fromCurrency, String toCurrency) {
        String strRate = null;

        HashMap mapConversions = (HashMap) PropertiesHandler.getCurrencies();
        ArrayList alCurrencies = listAllCurrencies(mapConversions);

        /**
         * If valid from and To currencies are not entered return null
         */

        if (!alCurrencies.contains(fromCurrency) || !alCurrencies.contains(toCurrency)) {
            return null;
        }

        HashMap mapVertex = getVertexesForAllCurrencies(alCurrencies);

        for (int i = 0; i < alCurrencies.size(); i++) {
            String currency = (String) alCurrencies.get(i);
            Vertex vertex = (Vertex) mapVertex.get(currency);

            // get all the mappings for that currency

            ArrayList alConversions = (ArrayList) mapConversions.get(currency);
            Edge[] toCurrencies = new Edge[0];
            if (null != alConversions) {
                toCurrencies = new Edge[alConversions.size()];
                for (int j = 0; j < alConversions.size(); j++) {
                    String destCurr = (String) alConversions.get(j);
                    Vertex dest = (Vertex) mapVertex.get(destCurr);
                    Edge edgeCurrency = new Edge(dest, 1);
                    toCurrencies[j] = edgeCurrency;
                }

            }
            vertex.adjacencies = toCurrencies;

        }

        Vertex source = (Vertex) mapVertex.get(fromCurrency);
        Vertex vertexToCurrency = (Vertex) mapVertex.get(toCurrency);

        Dijkstra.computePaths(source); // run Dijkstra

        ArrayList<Vertex> path = (ArrayList<Vertex>) Dijkstra.getShortestPathTo(vertexToCurrency);

        if (null != path && path.size() > 1) {
            strRate = getFinalRate(path);
        }

        return strRate;
    }

    /**
     * get the final rate based on shortest Path from the Dijistra algorithm
     * 
     * @param path
     * @return
     */
    private static String getFinalRate(ArrayList<Vertex> path) {

        String strRate;
        Double finalRate = (double) 1;

        for (int i = 1; i < path.size(); i++) {
            Vertex srcCurr = path.get(i - 1);
            Vertex destCurr = path.get(i);

            String key = srcCurr.name + "-" + destCurr.name;
            String rate = PropertiesHandler.getProperty(key);
            finalRate = finalRate * Double.parseDouble(rate);
        }
        strRate = "" + finalRate;

        return strRate;

    }

    /**
     * method to list all the currencies with rates
     * 
     * @param mapConversions
     * @return
     */
    private static ArrayList listAllCurrencies(HashMap mapConversions) {

        ArrayList alCurrencies = new ArrayList();
        Iterator<Entry<String, String>> it = mapConversions.entrySet().iterator();

        while (it.hasNext()) {
            Map.Entry pair = it.next();
            String key = (String) pair.getKey();

            if (!alCurrencies.contains(key)) {
                alCurrencies.add(key);
            }

            ArrayList dest = (ArrayList) mapConversions.get(key);
            for (int i = 0; i < dest.size(); i++) {
                String toCurr = (String) dest.get(i);
                if (!alCurrencies.contains(toCurr)) {
                    alCurrencies.add(toCurr);
                }
            }

        }

        // add all the
        return alCurrencies;

    }

    /**
     * method to get the vertex for running the algorithm
     * 
     * @param alCurrencies
     * @return
     */
    private static HashMap getVertexesForAllCurrencies(ArrayList alCurrencies) {

        HashMap mapVertex = new HashMap<>();
        for (int i = 0; i < alCurrencies.size(); i++) {

            String key = (String) alCurrencies.get(i);

            Vertex vertex = new Vertex(key);
            mapVertex.put(key, vertex);

        }
        return mapVertex;
    }

}
